### Using labels only
 python -m torch.distributed.launch train.py --name label2city_512p --fp16